# RPG Skill Rune Plugin - Resource Pack

이 리소스팩은 RPGSkillRunePlugin의 아이템 외형을 제공합니다.

## 적용 방법

1. 서버의 `server.properties`에서 `resource-pack` 항목에 이 zip 파일의 URL을 입력하세요.
2. 또는 플레이어가 직접 리소스팩 폴더에 넣어도 됩니다.
3. 플러그인에서 각 아이템은 `custom_model_data`를 통해 구분됩니다.

## 아이템 매핑

| 아이템 | material | custom_model_data | 설명 |
|--------|----------|-------------------|------|
| 일반 룬 | PAPER | 1 | 일반 등급 룬 |
| 레어 룬 | PAPER | 2 | 레어 등급 룬 |
| 에픽 룬 | PAPER | 3 | 에픽 등급 룬 |
| 유니크 룬 | PAPER | 4 | 유니크 등급 룬 |
| 레전더리 룬 | PAPER | 5 | 레전더리 등급 룬 |
| 추출 토큰 | AMETHYST_SHARD | 1 | 룬 추출에 사용 |
| 새로고침 토큰 | SUNFLOWER | 1 | 상점 새로고침에 사용 |
| 리제로 원석 | NETHER_STAR | 1 | 룬 초기화에 사용 |

## 텍스처 목록

- `assets/runeskill/textures/item/rune_normal.png` ~ `rune_legendary.png` - 등급별 보석형 룬
- `assets/runeskill/textures/item/extractor_token.png` - 추출 토큰
- `assets/runeskill/textures/item/refresh_token.png` - 새로고침 토큰
- `assets/runeskill/textures/item/rezero_stone.png` - 리제로 원석
