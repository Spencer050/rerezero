# RPG Skill Rune Plugin - Resource Pack

이 리소스팩은 RPGSkillRunePlugin의 육각형 룬 외형을 제공합니다.

## 적용 방법

1. 서버의 `server.properties`에서 `resource-pack` 항목에 이 zip 파일의 URL을 입력하세요.
2. 또는 플레이어가 직접 리소스팩 폴더에 넣어도 됩니다.
3. 플러그인에서 룬 아이템은 `PAPER`를 기본 아이템으로 하며, `custom_model_data`를 통해 등급별 육각형 룬 텍스처로 표시됩니다.

## custom_model_data 매핑

| 등급 | custom_model_data |
|------|-------------------|
| 노말 | 1 |
| 레어 | 2 |
| 에픽 | 3 |
| 유니크 | 4 |
| 레전더리 | 5 |

## 텍스처

- `assets/runeskill/textures/item/rune_normal.png` ~ `rune_legendary.png`
- 각 등급별로 육각형 색상과 중앙 문양이 다릅니다.
